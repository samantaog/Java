package com.generation.Eletronicos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EletronicosApplication {

	public static void main(String[] args) {
		SpringApplication.run(EletronicosApplication.class, args);
	}

}
