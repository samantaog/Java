package com.generation.Eletronicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EletronicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
